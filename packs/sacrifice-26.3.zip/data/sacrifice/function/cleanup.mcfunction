# Worshippers, Blood Priests and the Bull of Moloch no longer roam the realm: any left over from before are quietly taken away.
execute in sacrifice:sacrifice as @e[tag=sacrifice_mob] at @s run tp @s ~ -2000 ~
schedule function sacrifice:cleanup 100t replace
