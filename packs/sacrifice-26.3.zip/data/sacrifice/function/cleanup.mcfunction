# Moloch's own mobs (worshippers, the evoker acolytes, the bulls) don't despawn on their own, so they used to pile up.
# Every 5 seconds, any of them with nobody within 96 blocks is quietly taken away.
execute in sacrifice:sacrifice as @e[tag=sacrifice_worshipper_2] at @s unless entity @a[distance=..96] run tp @s ~ -2000 ~
execute in sacrifice:sacrifice as @e[tag=sacrifice_blood_priest_1] at @s unless entity @a[distance=..96] run tp @s ~ -2000 ~
execute in sacrifice:sacrifice as @e[tag=sacrifice_bull_of_moloch_3] at @s unless entity @a[distance=..96] run tp @s ~ -2000 ~
schedule function sacrifice:cleanup 100t replace
