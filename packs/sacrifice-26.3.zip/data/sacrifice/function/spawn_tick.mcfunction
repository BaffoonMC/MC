# Worshippers, Blood Priests and the Bull of Moloch no longer roam the realm. Kept empty so an old schedule ends quietly.
