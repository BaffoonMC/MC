# the realm's own mobs: checked once a second (the roll chances are per second)
# Blood Priest
execute as @a at @s if dimension sacrifice:sacrifice store result score @s sacrifice.near if entity @e[tag=sacrifice_blood_priest_1,distance=..72]
execute as @a[scores={sacrifice.near=..1}] at @s rotated ~ 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_blood_priest_1 positioned ^ ^ ^32 unless predicate sacrifice:in_temple run function sacrifice:mob/blood_priest_1/place
# Worshipper
execute as @a at @s if dimension sacrifice:sacrifice store result score @s sacrifice.near if entity @e[tag=sacrifice_worshipper_2,distance=..72]
execute as @a[scores={sacrifice.near=..2}] at @s rotated ~ 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_worshipper_2 positioned ^ ^ ^24 unless predicate sacrifice:in_temple run function sacrifice:mob/worshipper_2/place
execute as @a[scores={sacrifice.near=..2}] at @s rotated ~90 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_worshipper_2 positioned ^ ^ ^24 unless predicate sacrifice:in_temple run function sacrifice:mob/worshipper_2/place
execute as @a[scores={sacrifice.near=..2}] at @s rotated ~180 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_worshipper_2 positioned ^ ^ ^24 unless predicate sacrifice:in_temple run function sacrifice:mob/worshipper_2/place
execute as @a[scores={sacrifice.near=..2}] at @s rotated ~270 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_worshipper_2 positioned ^ ^ ^24 unless predicate sacrifice:in_temple run function sacrifice:mob/worshipper_2/place
# Bull of Moloch
execute as @a at @s if dimension sacrifice:sacrifice store result score @s sacrifice.near if entity @e[tag=sacrifice_bull_of_moloch_3,distance=..72]
execute as @a[scores={sacrifice.near=..0}] at @s rotated ~ 0 if dimension sacrifice:sacrifice if predicate sacrifice:roll_bull_of_moloch_3 positioned ^ ^ ^48 unless predicate sacrifice:in_temple run function sacrifice:mob/bull_of_moloch_3/place
schedule function sacrifice:spawn_tick 20t replace
