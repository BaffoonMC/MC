# Moloch eats only what is precious here: his father's World Egg, the golden apple of kings, and red dust (none grows in this world)
execute if items entity @s contents minecraft:dragon_egg run return run function sacrifice:offer/egg
execute if items entity @s contents minecraft:enchanted_golden_apple run return run function sacrifice:offer/apple
execute if items entity @s contents minecraft:redstone_block run return run function sacrifice:offer/redstone_block
execute if items entity @s contents minecraft:redstone run return run function sacrifice:offer/redstone
function sacrifice:offer/reject
