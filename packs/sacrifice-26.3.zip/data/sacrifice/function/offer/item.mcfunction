# Moloch eats only what can't be made: his father's World Egg, the golden apple of kings (thrown in here), and people
# (the ritual, run by the plugin). Everything else is spat out. Overrides the Sacrifice pack's own offer/item, which also took red dust.
execute if items entity @s contents minecraft:dragon_egg run return run function sacrifice:offer/egg
execute if items entity @s contents minecraft:enchanted_golden_apple run return run function sacrifice:offer/apple
function sacrifice:offer/reject
