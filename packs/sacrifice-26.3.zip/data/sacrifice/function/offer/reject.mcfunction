kill @s
particle minecraft:large_smoke ~ ~0.5 ~ 0.3 0.6 0.3 0.02 30
execute if score #msg sacrifice.offer matches ..0 run playsound minecraft:entity.blaze.death hostile @a ~ ~ ~ 1 0.4
execute as @p[distance=..24] run effect give @s minecraft:nausea 10 0
execute as @p[distance=..24] run effect give @s minecraft:hunger 20 1
execute if score #msg sacrifice.offer matches ..0 as @p[distance=..24] run tellraw @s {text:"Moloch spits it out. He wants his father's World Egg, the golden apple of kings, or one of you.",color:"dark_red",italic:true}
scoreboard players set #msg sacrifice.offer 30
