# #hunger only ever climbs (the plugin reads it and fills Moloch's Hunger); #total counts towards the realm's blessing
scoreboard players operation #hunger sacrifice.offer += #n sacrifice.offer
scoreboard players operation #total sacrifice.offer += #n sacrifice.offer
function sacrifice:offer/fed
