# a block of red stone: 18 points (1.8% Hunger) each, counted for the whole stack at once
execute store result score #n sacrifice.offer run data get entity @s Item.count
scoreboard players set #k sacrifice.offer 18
scoreboard players operation #n sacrifice.offer *= #k sacrifice.offer
function sacrifice:offer/feed
kill @s
execute if score #msg sacrifice.offer matches 1.. run return 0
particle minecraft:flame ~ ~0.5 ~ 0.4 0.6 0.4 0.03 40
playsound minecraft:entity.ravager.roar hostile @a ~ ~ ~ 1.5 0.7
execute as @p[distance=..24] run tellraw @s {text:"The red stone melts into the fire. Moloch drinks it.",color:"dark_red",italic:true}
execute as @p[distance=..24] run effect give @s minecraft:strength 300 0
scoreboard players set #msg sacrifice.offer 30
