$damage @s $(amt) minecraft:player_attack by @p
