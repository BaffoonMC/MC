tag @s remove sacrifice_thief_angry
effect clear @s minecraft:strength
function sacrifice:thief/flee_start
