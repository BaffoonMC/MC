# the visible figure: follow the body, pass damage on, vanish with it
execute unless entity @e[tag=sacrifice_thief,distance=..3] run return run tp @s ~ -1000 ~
execute store result score #h sacrifice.thief run data get entity @s Health
execute if score #h sacrifice.thief matches 1000.. run return 0
scoreboard players set #d sacrifice.thief 1000
scoreboard players operation #d sacrifice.thief -= #h sacrifice.thief
execute store result storage sacrifice:thief dmg.amt int 1 run scoreboard players get #d sacrifice.thief
data modify entity @s Health set value 1000.0f
execute as @n[tag=sacrifice_thief,distance=..3] run function sacrifice:thief/hurt with storage sacrifice:thief dmg
