tag @s add sacrifice_thief_fled
tag @s remove sacrifice_thief_grabbing
data modify entity @s CustomName set value "Bastard Thief"
data modify entity @s PersistenceRequired set value 1b
attribute @s minecraft:attack_damage base set 0
playsound minecraft:entity.vindicator.celebrate hostile @a ~ ~ ~ 1 1.5
particle minecraft:smoke ~ ~1 ~ 0.3 0.5 0.3 0.02 20
