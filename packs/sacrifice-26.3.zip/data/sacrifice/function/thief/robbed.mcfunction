# you were hit by a Bastard Thief: it grabs from your hotbar and runs
advancement revoke @s only sacrifice:thief_hit
execute if entity @n[tag=sacrifice_thief_angry,tag=!sacrifice_thief_fled,distance=..8] run return run function sacrifice:thief/punish
tag @n[tag=sacrifice_thief,tag=!sacrifice_thief_fled,distance=..8] add sacrifice_thief_grabbing
execute unless entity @e[tag=sacrifice_thief_grabbing,limit=1] run return 0
execute unless items entity @s hotbar.* * as @e[tag=sacrifice_thief_grabbing] at @s run return run function sacrifice:thief/anger
function sacrifice:thief/take
function sacrifice:thief/take
title @s actionbar {text:"Bastard Thief robbed you! Kill it to get your things back.",color:"red"}
playsound minecraft:entity.item.pickup player @s ~ ~ ~ 1 0.6
advancement grant @s only sacrifice:thief_robbed
execute as @e[tag=sacrifice_thief_grabbing] at @s run function sacrifice:thief/flee_start
execute store result score #say sacrifice.thief run random value 0..5
execute if score #say sacrifice.thief matches 0 run tellraw @s ["",{text:"[",color:"#555555"},{text:"T",color:"#C83232"},{text:"h",color:"#CD4444"},{text:"i",color:"#D25656"},{text:"e",color:"#D66868"},{text:"f",color:"#DB7A7A"},{text:"] ",color:"#555555"},{text:"Bastard Thief",color:"#AAAAAA"},{text:" > ",color:"#FFAA00"},{text:"You'll never see your stuff again, mate.",color:"white"}]
execute if score #say sacrifice.thief matches 1 run tellraw @s ["",{text:"[",color:"#555555"},{text:"T",color:"#C83232"},{text:"h",color:"#CD4444"},{text:"i",color:"#D25656"},{text:"e",color:"#D66868"},{text:"f",color:"#DB7A7A"},{text:"] ",color:"#555555"},{text:"Bastard Thief",color:"#AAAAAA"},{text:" > ",color:"#FFAA00"},{text:"Born yesterday, were you?",color:"white"}]
execute if score #say sacrifice.thief matches 2 run tellraw @s ["",{text:"[",color:"#555555"},{text:"T",color:"#C83232"},{text:"h",color:"#CD4444"},{text:"i",color:"#D25656"},{text:"e",color:"#D66868"},{text:"f",color:"#DB7A7A"},{text:"] ",color:"#555555"},{text:"Bastard Thief",color:"#AAAAAA"},{text:" > ",color:"#FFAA00"},{text:"Cheers, you're a star.",color:"white"}]
execute if score #say sacrifice.thief matches 3 run tellraw @s ["",{text:"[",color:"#555555"},{text:"T",color:"#C83232"},{text:"h",color:"#CD4444"},{text:"i",color:"#D25656"},{text:"e",color:"#D66868"},{text:"f",color:"#DB7A7A"},{text:"] ",color:"#555555"},{text:"Bastard Thief",color:"#AAAAAA"},{text:" > ",color:"#FFAA00"},{text:"Next time, just say no.",color:"white"}]
execute if score #say sacrifice.thief matches 4 run tellraw @s ["",{text:"[",color:"#555555"},{text:"T",color:"#C83232"},{text:"h",color:"#CD4444"},{text:"i",color:"#D25656"},{text:"e",color:"#D66868"},{text:"f",color:"#DB7A7A"},{text:"] ",color:"#555555"},{text:"Bastard Thief",color:"#AAAAAA"},{text:" > ",color:"#FFAA00"},{text:"Thanks, I'll sell this lot down the market.",color:"white"}]
execute if score #say sacrifice.thief matches 5 run tellraw @s ["",{text:"[",color:"#555555"},{text:"T",color:"#C83232"},{text:"h",color:"#CD4444"},{text:"i",color:"#D25656"},{text:"e",color:"#D66868"},{text:"f",color:"#DB7A7A"},{text:"] ",color:"#555555"},{text:"Bastard Thief",color:"#AAAAAA"},{text:" > ",color:"#FFAA00"},{text:"Keep the watch, I'll take the rest.",color:"white"}]
