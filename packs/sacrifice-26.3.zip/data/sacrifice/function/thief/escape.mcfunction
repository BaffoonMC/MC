# got away with it
particle minecraft:large_smoke ~ ~1 ~ 0.3 0.6 0.3 0.02 30
playsound minecraft:entity.illusioner.mirror_move hostile @a ~ ~ ~ 1 0.8
item replace entity @s armor.chest with air
tp @n[tag=sacrifice_thief_skin,distance=..4] ~ -1000 ~
tp @s ~ -1000 ~
