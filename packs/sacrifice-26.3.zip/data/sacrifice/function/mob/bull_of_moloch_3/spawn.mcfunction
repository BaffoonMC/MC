# test it: stand somewhere open and run /function sacrifice:mob/bull_of_moloch_3/spawn
function sacrifice:mob/bull_of_moloch_3/group
